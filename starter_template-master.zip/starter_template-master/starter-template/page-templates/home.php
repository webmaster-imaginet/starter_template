<?php //Template Name: Home?>
<?php get_header()?>
<div class="page-wrap homepage">
  Hello from home
</div>
<?php get_footer()?>
